from django.contrib import admin

from django.urls import path
from . import views
from base import views


urlpatterns = [
    
	path('', views.home,name='home'),
    path('dash', views.dash,name='dash'),
    path('appointment', views.appointment,name= 'appointment'),
    path('takeApp/', views.takeApp, name='takeApp'),

    path('cnfr',views.cnfr,name='cnfr'),
    path('showApp/', views.showApp, name='showApp'),

    path('doc', views.doctors, name= 'doctors'),
    path('dept', views.dept, name= 'dept'),
    path('logout', views.logout, name= 'logout')
]