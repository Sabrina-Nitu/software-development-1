from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect


def home(request):
	return render(request, 'home.html')
def dash(request):
     return render(request, 'dash.html')
def appointment(request):
    return render(request, 'appointment.html')
def takeApp(request):
    return render(request, 'takeApp.html')
def cnfr(request):
     return render(request, 'cnfr.html')
def showApp(request):
    return render(request, 'showApp.html')
def doctors(request):
    return render(request, 'doctors.html')
def dept(request):
    return render(request, 'dept.html')
def logout(request):
    return render(request, 'logout.html')


